setInterval(function(){
    console.log("entro")
    window.location.href="http://127.0.0.1:8000/obtenerList";
    console.log("despues")
}, 1000);