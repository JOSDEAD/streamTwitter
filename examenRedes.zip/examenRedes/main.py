from flask import Flask, request, render_template,redirect,url_for

from werkzeug.utils import secure_filename
import os
from flask import send_from_directory


import mysql.connector


#twitt
#user
#hora
#texto

app = Flask(__name__)





class Tweets:
    def __init__(self,user,hora,texto):
        self.user = user
        self.hora = hora
        self.texto = texto



@app.route('/obtenerLista')
def obtenerLista():
    lista = []

    cnx = mysql.connector.connect(user='josdead', password='12345',
                                  host='34.219.19.185',
                                  database='redes',
                                  port=3306)
    cursorRegistros = cnx.cursor()
    query = "Select * from twitt";

    cursorRegistros.execute(query)
    fila = cursorRegistros.fetchall()
    for item in fila:
        user = str(item[0])
        hora = str(item[1])
        texto = str(item[2])
        element = Tweets(user,hora,texto)
        lista.append(element)
    #return str(len(fila))

    return render_template('paginaWeb.html', lista = lista)

if __name__ == '__main__':
    app.run(port=8000, debug=True)
